# Elastocalorics Market Dataset

This repository contains a structured dataset created from publicly available information on the **Elastocalorics Market** (Next Move Strategy Consulting).  
It is intended for research, prototyping, demonstration, and educational use. This dataset includes only public summary-level information and is **not** a replacement for the full paid report.

**Source:** NextMSC — Elastocalorics Market.  
**Report page:** https://www.nextmsc.com/report/elastocalorics-market-3556

## Files included
- `market_overview.csv` — extracted headline figures (market size, forecast, CAGR) where publicly available.  
- `segmentation.csv` — segmentation categories such as material type, application, technology, and region.  
- `metadata.json` — metadata about the dataset (source URL, extraction date, included files).  
- `source.txt` — short excerpt / provenance pointing to the report page.  
- `README.md` — this file.

## Usage
1. Download and unzip the archive.  
2. Inspect `market_overview.csv` for headline figures.  
3. Use `segmentation.csv` for categorical breakdowns.  
4. Cite the original report if you use data or insights from the full report.

## Limitations
- Contains only publicly available summary information.  
- The original report likely contains more detailed proprietary tables which are not included here.  
- Use for research and educational purposes; verify with primary source for commercial use.

## License
Provided for research and educational use. Respect NextMSC rights for the full report content.
